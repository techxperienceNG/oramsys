const jwtSecret =
  process.env.SECRET_KEY || "0a6b944d-d2fb-46fc-a85e-0295c986cd9f";

module.exports = { jwtSecret }